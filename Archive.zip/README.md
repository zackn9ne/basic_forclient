## The eblast template for macaulay now
- - -
### This is Macaulay's eblast template

This file resides on
- zackn9ne.github.io/basic_forclient/images
- zackn9ne.github.io/basic_forclient

This must be used in conjunction with
- mc:edit editable regions, specifically named via Mailchimp API

When making updates!
- push origin to gh-pages branch
